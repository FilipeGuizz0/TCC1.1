<?php
include('auth.php');
include('config.php');

$mensagem = ""; // Variável para armazenar mensagens
$classe_mensagem = ""; // Variável para armazenar a classe da mensagem

$sql_grupo = "SELECT codigo, descricao FROM grupo";
$pesquisar_grupo = mysqli_query($con, $sql_grupo);

if (isset($_POST['gravar'])) {
    // Receber as variáveis do HTML
    $codigo = $_POST['codigo'];
    $descricao = $_POST['descricao'];
    $codgrupo = $_POST['codgrupo'];

    // Usando declaração preparada para prevenir injeção de SQL
    $stmt = mysqli_prepare($con, "INSERT INTO subgrupo (codigo, descricao, codgrupo) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, 'iss', $codigo, $descricao, $codgrupo);

    $resultado = mysqli_stmt_execute($stmt);

    if ($resultado) {
        $mensagem = "Dados gravados com sucesso.";
        $classe_mensagem = "mensagem-sucesso";
    } else {
        $mensagem = "Erro ao gravar os dados: " . mysqli_error($con);
        $classe_mensagem = "mensagem-erro";
    }

    mysqli_stmt_close($stmt);
}

if (isset($_POST['alterar'])) {
    $codigo = $_POST['codigo'];
    $descricao = $_POST['descricao'];
    $codgrupo = $_POST['codgrupo'];

    // Usando declaração preparada para prevenir injeção de SQL
    $stmt = mysqli_prepare($con, "UPDATE subgrupo SET descricao = ? WHERE codigo = ?");
    mysqli_stmt_bind_param($stmt, 'si', $descricao, $codigo);

    $resultado = mysqli_stmt_execute($stmt);

    if ($resultado) {
        $mensagem = "Dados alterados com sucesso.";
        $classe_mensagem = "mensagem-sucesso";
    } else {
        $mensagem = "Erro ao alterar os dados: " . mysqli_error($con);
        $classe_mensagem = "mensagem-erro";
    }

    mysqli_stmt_close($stmt);
}

if (isset($_POST['excluir'])) {
    $codigo = $_POST['codigo'];

    // Usando declaração preparada para prevenir injeção de SQL
    $stmt = mysqli_prepare($con, "DELETE FROM subgrupo WHERE codigo = ?");
    mysqli_stmt_bind_param($stmt, 'i', $codigo);

    $resultado = mysqli_stmt_execute($stmt);

    if ($resultado) {
        $mensagem = "Dados excluídos com sucesso.";
        $classe_mensagem = "mensagem-sucesso";
    } else {
        $mensagem = "Erro ao excluir os dados: " . mysqli_error($con);
        $classe_mensagem = "mensagem-erro";
    }

    mysqli_stmt_close($stmt);
} elseif ($_POST['acao'] == 'pesquisar') {
    // Lógica para pesquisa
    $search_term = $_POST['search_term'];
    $query = "SELECT * FROM  subgrupo WHERE codigo LIKE '%$search_term%' OR codgrupo LIKE '%$search_term%'";
    $result = mysqli_query($con, $query);
} else {
    // Lógica padrão para obter e exibir todos os subgrupos na tabela
    $query = "SELECT * FROM  subgrupo";
    $result = mysqli_query($con, $query);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Style/style.css">
    <title>Cadastro Subgrupo</title>
    <link rel="icon" href="img/oliares.png" type="image/x-icon">
    <style>
        .mensagem {
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
            font-weight: bold;
            text-align: center;
        }

        .mensagem-sucesso {
            background-color: #4CAF50; /* Verde */
            color: white;
        }

        .mensagem-erro {
            background-color: #f44336; /* Vermelho */
            color: white;
        }
        .botao-excluir {
            background-color: #f44336; /* Vermelho */
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        #guia-icon {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 50%;
            padding: 10px;
            font-size: 20px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        #guia-icon:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div id="box">
        <div id='voltar'>
            <a href="home.php"><button type="submit" id="search-button" style="height: 40px;">Voltar</button></a>
        </div>
        <form name="formulario" method="post" action="subgrupo.php">
            <h1>Cadastro Subgrupo</h1><br><br>
            Código:
            <input type="text" name="codigo" id="codigo" size=50 required>
            <br>
            Descrição:
            <input type="text" name="descricao" id="descricao" size=50 required>
            <br>
            Grupo: <select name="codgrupo" id="codgrupo" required>
                <option value=0 selected="selected">Selecione o grupo ...</option>
                <?php
                if (mysqli_num_rows($pesquisar_grupo) == 0) {
                    echo '<h1>Sua busca por grupo não retornou resultados ... </h1>';
                } else {
                    while ($resultado = mysqli_fetch_array($pesquisar_grupo)) {
                        echo '<option value="' . $resultado['codigo'] . '">' .
                            utf8_encode($resultado['descricao']) . '</option>';
                    }
                }
                ?>
            </select>
            <br><br>

            <input type="submit" name="gravar" id="gravar" value="Gravar">
            <input type="submit" name="alterar" id="alterar" value="Alterar">
            
        </form>
        <?php
        if (!empty($mensagem)) {
            echo "<p class='mensagem $classe_mensagem'>$mensagem</p>";
        }
        ?>
        <div class="container">
            <div id="buttons-container">
                <br>
                <form id="search-form" method="post" action="">
                    <input type="text" id="search-input" name="search_term" style="height:30px;"
                        placeholder="Digite o código para pesquisar">
                    <button type="submit" id="search-button" name="acao" value="pesquisar"
                        style="height: 40px;">Pesquisar</button>
                </form>
            </div>

            <table>
                <tr>
                    <th>Código</th>
                    <th>Descrição</th>
                    <th>Grupo</th>
                    <th>Ação</th>
                </tr>
                <?php
// Supondo que você já tenha a conexão com o banco de dados ($con) e a consulta ($result)

while ($row = mysqli_fetch_assoc($result)) {
    // Obtenha o código do grupo da linha atual
    $codGrupo = $row['codgrupo'];

    // Consulta para obter a descrição do grupo com base no código
    $consultaGrupo = "SELECT descricao FROM grupo WHERE codigo = $codGrupo";
    $resultGrupo = mysqli_query($con, $consultaGrupo);

    // Verifique se a consulta foi bem-sucedida
    if ($resultGrupo) {
        // Obtenha a descrição do grupo da consulta
        $rowGrupo = mysqli_fetch_assoc($resultGrupo);
        $descricaoGrupo = $rowGrupo['descricao'];

        // Exiba os dados na tabela
        echo "<tr>
                <td>{$row['codigo']}</td>
                <td>{$row['descricao']}</td>
                <td>{$descricaoGrupo}</td>
                <td>
                            <form method='post' action='subgrupo.php' onsubmit='return confirm(\"Deseja realmente excluir?\")'>
                                <input type='hidden' name='codigo' value='{$row['codigo']}'>
                                <input type='submit' name='excluir' value='Excluir'  class='botao-excluir'>
                            </form>
                </td>
            </tr>";
    } else {
        // Trate o erro na consulta do grupo
        echo "Erro na consulta do grupo: " . mysqli_error($con);
    }

    // Lembre-se de fechar o resultado da consulta do grupo
    mysqli_free_result($resultGrupo);
}

// Feche a conexão com o banco de dados
mysqli_close($con);
?>

            </table>
        </div>
    </div>
       <!-- Ícone de guia -->
       <a id="guia-icon" href="ajuda.html">&#9432;</a>
    </div>
</body>
</html>
