<?php
include('auth.php');
include('config.php');

$mensagem = ""; // Variável para armazenar mensagens
$classe_mensagem = ""; // Variável para armazenar a classe da mensagem

$sql_contapagar = "SELECT codigo FROM contapagar";
$pesquisar_contapagar = mysqli_query($con, $sql_contapagar);

$sql_contacorrente = "SELECT codigo FROM contacorrente";
$pesquisar_contacorrente = mysqli_query($con, $sql_contacorrente);

if (isset($_POST['gravar'])) {
    // Receber as variáveis do HTML
    $codigo = $_POST['codigo'];
    $valor = $_POST['valor'];
    $datamovimento = $_POST['datamovimento'];
    $juros = $_POST['juros'];
    $codcontapagar = $_POST['codcontapagar'];
    $parcela = $_POST['parcela'];
    $codcontacorrente = $_POST['codcontacorrente'];

    // Calcular o valor total
    $total = $valor + ($valor * ($juros / 100));

    // Inserir os dados no banco de dados
    $sql = "INSERT INTO movimentopagar (codigo, valor, datamovimento, juros, total, codcontapagar, parcela, codcontacorrente)
          VALUES ('$codigo', '$valor', '$datamovimento', '$juros', '$total', '$codcontapagar', '$parcela', '$codcontacorrente')";

    $resultado = mysqli_query($con, $sql);

    // Atualizar saldos nas contas
    $atualizarSql = "UPDATE contapagar SET valor = valor - '$total', parcela = parcela - '$parcela' WHERE codigo = '$codcontapagar'";
    $atualizarSqlCorrente = "UPDATE contacorrente SET saldoatual = saldoatual - '$total' WHERE codigo = '$codcontacorrente'";
    $atualizarResultado = mysqli_query($con, $atualizarSql);
    $atualizarResultado = mysqli_query($con, $atualizarSqlCorrente);

    // Exibir mensagem com base no resultado da operação
    if ($resultado) {
        $mensagem = "Dados gravados com sucesso.";
        $classe_mensagem = "mensagem-sucesso";
    } else {
        $mensagem = "Erro ao gravar os dados: " . mysqli_error($con);
        $classe_mensagem = "mensagem-erro";
    }
}

if (isset($_POST['alterar'])) {
    // Receber as variáveis do HTML
    $codigo = $_POST['codigo'];
    $valor = $_POST['valor'];
    $datamovimento = $_POST['datamovimento'];
    $juros = $_POST['juros'];
    $codcontapagar = $_POST['codcontapagar'];
    $parcela = $_POST['parcela'];
    $codcontacorrente = $_POST['codcontacorrente'];

    // Recalcular o valor total
    $total = $valor + ($valor * ($juros / 100));

    // Atualizar dados na tabela "movimentopagar"
    $sql = "UPDATE movimentopagar SET valor = '$valor', juros = '$juros', total = '$total', datamovimento = '$datamovimento'
            WHERE codigo = '$codigo'";

    $resultado = mysqli_query($con, $sql);

    // Exibir mensagem com base no resultado da operação
    if ($resultado) {
        $mensagem = "Dados alterados com sucesso.";
        $classe_mensagem = "mensagem-sucesso";
    } else {
        $mensagem = "Erro ao alterar os dados: " . mysqli_error($con);
        $classe_mensagem = "mensagem-erro";
    }
}

if (isset($_POST['excluir'])) {
    // Receber as variáveis do HTML
    $codigo = $_POST['codigo'];
    $valor = $_POST['valor'];
    $datamovimento = $_POST['datamovimento'];
    $juros = $_POST['juros'];
    $total = $_POST['total'];
    $codcontapagar = $_POST['codcontapagar'];
    $parcela = $_POST['parcela'];
    $codcontacorrente = $_POST['codcontacorrente'];

    // Excluir dados da tabela "movimentopagar"
    $sql = "DELETE FROM movimentopagar WHERE codigo = '$codigo'";

    $resultado = mysqli_query($con, $sql);

    // Exibir mensagem com base no resultado da operação
    if ($resultado) {
        $mensagem = "Dados excluídos com sucesso.";
        $classe_mensagem = "mensagem-sucesso";
    } else {
        $mensagem = "Erro ao excluir os dados: " . mysqli_error($con);
        $classe_mensagem = "mensagem-erro";
    }
} elseif ($_POST['acao'] == 'pesquisar') {
    // Lógica para pesquisa
    $search_term = $_POST['search_term'];
    $query = "SELECT * FROM movimentopagar WHERE codigo LIKE '%$search_term%' OR datamovimento LIKE '%$search_term%'";
    $result = mysqli_query($con, $query);
} else {
    // Lógica padrão para obter e exibir todos os registros na tabela
    $query = "SELECT * FROM movimentopagar";
    $result = mysqli_query($con, $query);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style/style.css">
    <meta charset="UTF-8">
    <link rel="icon" href="img/oliares.png" type="image/x-icon">
    <title>Movimento Pagar</title>
    <style>
        .mensagem {
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
            font-weight: bold;
            text-align: center;
        }

        .mensagem-sucesso {
            background-color: #4CAF50; /* Verde */
            color: white;
        }

        .mensagem-erro {
            background-color: #f44336; /* Vermelho */
            color: white;
        }
        .botao-excluir {
            background-color: #f44336; /* Vermelho */
            color: white;
            padding: 8px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        #guia-icon {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 50%;
            padding: 10px;
            font-size: 20px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        #guia-icon:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div id="box">
        <div id='voltar'>
            <a href="home.php"><button type="submit" id="search-button" style="height: 40px;">Voltar</button></a>
        </div>
        <form name="formulario" method="post" action="movimentopagar.php">
            <h1>Movimento conta pagar</h1><br><br>
            Código:
            <input type="text" name="codigo" id="codigo" size=50 required><br>
            Data Movimento Pagar:
            <input type="date" name="datamovimento" id="datamovimento" size=50 required><br>
            Valor:
            <input type="number" name="valor" id="valor" size=50 required><br>
            Juros:
            <input type="number" name="juros" id="juros" size=50 required><br>
            Conta Pagar:
            <select name="codcontapagar" id="codcontapagar" required>
                <option value=0 selected="selected">Selecione código...</option>
                <?php
                if (mysqli_num_rows($pesquisar_contapagar) == 0) {
                    echo '<h1>Sua busca por contapagar não retornou resultados...</h1>';
                } else {
                    while ($resultado = mysqli_fetch_array($pesquisar_contapagar)) {
                        echo '<option value="' . $resultado['codigo'] . '">' .
                            utf8_encode($resultado['codigo']) . '</option>';
                    }
                }
                ?>
            </select>
            <br>
            Parcela:
            <input type="number" name="parcela" id="parcela" size=50 required><br>
            Conta Corrente:
            <select name="codcontacorrente" id="codcontacorrente">
                <option value=0 selected="selected">Selecione código...</option>
                <?php
                if (mysqli_num_rows($pesquisar_contacorrente) == 0) {
                    echo '<h1>Sua busca por contacorrente não retornou resultados...</h1>';
                } else {
                    while ($resultado = mysqli_fetch_array($pesquisar_contacorrente)) {
                        echo '<option value="' . $resultado['codigo'] . '">' .
                            utf8_encode($resultado['codigo']) . '</option>';
                    }
                }
                ?>
            </select>
            <br><br>
            <input type="submit" name="gravar" id="gravar" value="Gravar">
            <input type="submit" name="alterar" id="alterar" value="Alterar">
              
            
        </form>
        <?php
        if (!empty($mensagem)) {
            echo "<p class='mensagem $classe_mensagem'>$mensagem</p>";
        }
        ?>
        <div class="container">
            <div id="buttons-container">
                <br>
                <form id="search-form" method="post" action="">
                    <input type="text" id="search-input" name="search_term" style="height:30px;" placeholder="Digite o código para pesquisar">
                    <button type="submit" id="search-button" name="acao" value="pesquisar" style="height: 40px;">Pesquisar</button>
                </form>
            </div>
           
            <table>
    <tr>
        <th>Código</th>
        <th>Data do Movimento</th>
        <th>Valor</th>
        <th>Juros</th>
        <th>Total</th>
        <th>Conta</th>
        <th>Parcela</th>
        <th>Conta Corrente</th>
        <th>Ação</th> <!-- Nova coluna para o botão de Excluir -->
    </tr>
    <?php
    while ($row = mysqli_fetch_assoc($result)) {
        // Formate os valores como quantias de dinheiro
        $valorFormatado = "R$ " . number_format($row['valor'], 2, ',', '.');
        $totalFormatado = "R$ " . number_format($row['total'], 2, ',', '.');

        // Formate o juros como percentual
        $jurosFormatado = $row['juros'] . "%";

        echo "<tr>
        <td>{$row['codigo']}</td>
        <td>{$row['datamovimento']}</td>
        <td>{$valorFormatado}</td>
        <td>{$jurosFormatado}</td>
        <td>{$totalFormatado}</td>
        <td>{$row['codcontapagar']}</td>
        <td>{$row['parcela']}</td>
        <td>{$row['codcontacorrente']}</td>
        <td>
            <form method='post' action='movimentopagar.php' onsubmit='return confirm(\"Deseja realmente excluir?\")'>
                <input type='hidden' name='codigo' value='{$row['codigo']}'>
                <input type='submit' name='excluir' value='Excluir' class='botao-excluir'>
            </form>
        </td>
    </tr>";
    }
    ?>
</table>
        </div>
    </div>
       <!-- Ícone de guia -->
       <a id="guia-icon" href="ajuda.html">&#9432;</a>
    </div>
</body>
</html>
