<?php
include('auth.php');
include('config.php');

$mensagem = ""; // Variável para armazenar mensagens
$classe_mensagem = ""; // Variável para armazenar a classe da mensagem

$sql_produtostamanho = "SELECT codigo FROM produtostamanho";
$pesquisar_produtostamanho = mysqli_query($con, $sql_produtostamanho);

if (isset($_POST['gravar'])) {
    // Receber as variáveis do HTML
    $codigo = $_POST['codigo'];
    $codProdutoTamanho = $_POST['codProdutoTamanho'];
    $quantidade = $_POST['quantidade'];
    $movimento = $_POST['movimento'];
    $dataMovimento = $_POST['dataMovimento'];

    // Converter a data para o formato YYYY-MM-DD
    $dataMovimentoFormatada = date('Y-m-d', strtotime($dataMovimento));

    // Determinar a operação com base no tipo de movimento
    if ($movimento == 'Saída') {
        // Saída: diminuir a quantidade
        $atualizarSqlprodutostamanho = "UPDATE produtostamanho SET quantidadeatual = quantidadeatual - ? WHERE codigo = ?";
    } elseif ($movimento == 'Entrada') {
        // Entrada: aumentar a quantidade
        $atualizarSqlprodutostamanho = "UPDATE produtostamanho SET quantidadeatual = quantidadeatual + ? WHERE codigo = ?";
    } else {
        // Movimento desconhecido, manipule conforme necessário
        $mensagem = "Tipo de movimento desconhecido.";
        $classe_mensagem = "mensagem-erro";
    }

    // Executar a consulta de atualização de quantidade
    if (isset($atualizarSqlprodutostamanho)) {
        $stmtAtualizar = mysqli_prepare($con, $atualizarSqlprodutostamanho);
        mysqli_stmt_bind_param($stmtAtualizar, 'ss', $quantidade, $codProdutoTamanho);
        $resultadoAtualizar = mysqli_stmt_execute($stmtAtualizar);

        // Verificar se a atualização foi bem-sucedida
        if (!$resultadoAtualizar) {
            $mensagem = "Erro ao atualizar a quantidade: " . mysqli_error($con);
            $classe_mensagem = "mensagem-erro";
        }

        // Fechar a instrução preparada de atualização
        mysqli_stmt_close($stmtAtualizar);
    }

    // Inserir os dados na tabela movimentoestoque
    $sql = "INSERT INTO movimentoestoque (codigo, codProdutoTamanho, quantidade, movimento, dataMovimento) 
            VALUES (?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($con, $sql);

    // Verificar se a preparação foi bem-sucedida
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssss', $codigo, $codProdutoTamanho, $quantidade, $movimento, $dataMovimentoFormatada);
        $resultado = mysqli_stmt_execute($stmt);

        // Exibir mensagem com base no resultado da operação
        if ($resultado) {
            $mensagem = "Dados gravados com sucesso.";
            $classe_mensagem = "mensagem-sucesso";
        } else {
            $mensagem = "Erro ao gravar os dados: " . mysqli_error($con);
            $classe_mensagem = "mensagem-erro";
        }

        // Fechar a instrução preparada de inserção
        mysqli_stmt_close($stmt);
    } else {
        $mensagem = "Erro na preparação da instrução SQL.";
        $classe_mensagem = "mensagem-erro";
    }
}



if (isset($_POST['alterar'])) {
    // Receber as variáveis do HTML
    $codigo = $_POST['codigo'];
    $codProdutoTamanho = $_POST['codProdutoTamanho'];
    $quantidade = $_POST['quantidade'];
    $movimento = $_POST['movimento'];
    $dataMovimento = $_POST['dataMovimento'];
    
    // Usar instrução preparada para evitar injeção de SQL
    $sql = "UPDATE movimentoestoque SET codProdutoTamanho = ?, quantidade = ?, movimento = ?, dataMovimento = ? WHERE codigo = ?";
    $stmt = mysqli_prepare($con, $sql);

    // Verificar se a preparação foi bem-sucedida
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssss', $codProdutoTamanho, $quantidade, $movimento, $dataMovimento, $codigo);
        $resultado = mysqli_stmt_execute($stmt);

        // Ajustar a quantidade com base no tipo de movimento
        $ajusteQuantidade = ($movimento == 'Saída') ? -1 * $quantidade : $quantidade;

        // Usar instrução preparada para evitar injeção de SQL
        $atualizarSqlprodutostamanho = "UPDATE produtostamanho SET quantidadeatual = quantidadeatual + ? WHERE codigo = ?";
        $stmtAtualizar = mysqli_prepare($con, $atualizarSqlprodutostamanho);

        // Verificar se a preparação foi bem-sucedida
        if ($stmtAtualizar) {
            mysqli_stmt_bind_param($stmtAtualizar, 'ss', $ajusteQuantidade, $codProdutoTamanho);
            $resultadoAtualizar = mysqli_stmt_execute($stmtAtualizar);

            // Verificar se a atualização foi bem-sucedida
            if (!$resultadoAtualizar) {
                $mensagem = "Erro ao atualizar a quantidade: " . mysqli_error($con);
                $classe_mensagem = "mensagem-erro";
            }

            // Fechar a instrução preparada de atualização
            mysqli_stmt_close($stmtAtualizar);
        } else {
            $mensagem = "Erro na preparação da instrução SQL de atualização de quantidade.";
            $classe_mensagem = "mensagem-erro";
        }

        // Exibir mensagem com base no resultado da operação
        if ($resultado) {
            $mensagem = "Dados alterados com sucesso.";
            $classe_mensagem = "mensagem-sucesso";
        } else {
            $mensagem = "Erro ao alterar os dados: " . mysqli_error($con);
            $classe_mensagem = "mensagem-erro";
        }

        // Fechar a instrução preparada
        mysqli_stmt_close($stmt);
    } else {
        $mensagem = "Erro na preparação da instrução SQL.";
        $classe_mensagem = "mensagem-erro";
    }
}


if (isset($_POST['excluir'])) {
    // Receber as variáveis do HTML
    $codigo = $_POST['codigo'];
    $codProdutoTamanho = $_POST['codProdutoTamanho'];
    $quantidade = $_POST['quantidade'];
    $movimento = $_POST['movimento'];
    $dataMovimento = $_POST['dataMovimento'];
   
    // Usar instrução preparada para evitar injeção de SQL
    $sql = "DELETE FROM movimentoestoque WHERE codigo = ?";
    $stmt = mysqli_prepare($con, $sql);

    // Verificar se a preparação foi bem-sucedida
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 's', $codigo);
        $resultado = mysqli_stmt_execute($stmt);

        // Exibir mensagem com base no resultado da operação
        if ($resultado) {
            $mensagem = "Dados excluídos com sucesso.";
            $classe_mensagem = "mensagem-sucesso";
        } else {
            $mensagem = "Erro ao excluir os dados: " . mysqli_error($con);
            $classe_mensagem = "mensagem-erro";
        }

        // Fechar a instrução preparada
        mysqli_stmt_close($stmt);
    } else {
        $mensagem = "Erro na preparação da instrução SQL.";
        $classe_mensagem = "mensagem-erro";
    }
} elseif ($_POST['acao'] == 'pesquisar') {
    // Lógica para pesquisa
    $search_term = $_POST['search_term'];
    $query = "SELECT * FROM movimentoestoque WHERE codigo LIKE '%$search_term%' OR dataMovimento LIKE '%$search_term%'";
    $result = mysqli_query($con, $query);
} else {
    // Lógica padrão para obter e exibir todos os registros da tabela "movimentoestoque"
    $query = "SELECT * FROM movimentoestoque";
    $result = mysqli_query($con, $query);
}
?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <title>Movimento Estoque</title>
    <link rel="stylesheet" href="Style/style.css">
    <link rel="icon" href="img/oliares.png" type="image/x-icon">
    <style>
        .mensagem {
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
            font-weight: bold;
            text-align: center;
        }

        .mensagem-sucesso {
            background-color: #4CAF50; /* Verde */
            color: white;
        }

        .mensagem-erro {
            background-color: #f44336; /* Vermelho */
            color: white;
        }
        .botao-excluir {
            background-color: #f44336; /* Vermelho */
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        #guia-icon {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 50%;
            padding: 10px;
            font-size: 20px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        #guia-icon:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div id="box">
        <div id='voltar'>
            <a href="home.php"><button type="submit" id="search-button" style="height: 40px;">Voltar</button></a>
        </div>
        <form name="formulario" method="post" action="movimentoestoque.php">
            <h1>Movimento Estoque</h1><br><br>
            Código:
            <input type="text" name="codigo" id="codigo" size=50 required><br>
            Produto:
            <select name="codProdutoTamanho" id="codProdutoTamanho" required>
                <option value=0 selected="selected">Selecione código...</option>
                <?php
                if (mysqli_num_rows($pesquisar_produtostamanho) == 0) {
                    echo '<h1>Sua busca por produtostamanho não retornou resultados...</h1>';
                } else {
                    while ($resultado = mysqli_fetch_array($pesquisar_produtostamanho)) {
                        echo '<option value="' . $resultado['codigo'] . '">' .
                            utf8_encode($resultado['codigo']) . '</option>';
                    }
                }
                ?>
            </select>
            <br>
            Quantidade:
            <input type="number" name="quantidade" id="quantidade" size=50 required><br>
            Movimento:
            <select name="movimento" id="movimento" required>
                <option value="Saída">Saída</option>
                <option value="Entrada">Entrada</option>
                
            </select>
            <br>
            Data Movimento:
            <input type="date" name="dataMovimento" id="dataMovimento"  required>
            <br><br>
            <input type="submit" name="gravar" id="gravar" value="Gravar">
            <input type="submit" name="alterar" id="alterar" value="Alterar">
            
            
        </form>
        <?php
        if (!empty($mensagem)) {
            echo "<p class='mensagem $classe_mensagem'>$mensagem</p>";
        }
        ?>
        <div class="container">
            <div id="buttons-container">
                <br>
                <form id="search-form" method="post" action="">
                    <input type="text" id="search-input" name="search_term" style="height:30px;" placeholder="Digite o código para pesquisar">
                    <button type="submit" id="search-button" name="acao" value="pesquisar" style="height: 40px;">Pesquisar</button>
                </form>
            </div>
            <table>
                <tr>
                    <th>Código</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Movimento</th>
                    <th>Data Movimento</th>
                    <th>Ação</th>
                </tr>
                <?php
while ($row = mysqli_fetch_assoc($result)) {
    // Formate os valores como quantias de dinheiro

    echo "<tr>
            <td>{$row['codigo']}</td>
            <td>{$row['codProdutoTamanho']}</td>
            <td>{$row['quantidade']}</td>
            <td>{$row['movimento']}</td>
            <td>{$row['dataMovimento']}</td>
            <td>
                            <form method='post' action='movimentoestoque.php' onsubmit='return confirm(\"Deseja realmente excluir?\")'>
                                <input type='hidden' name='codigo' value='{$row['codigo']}'>
                                <input type='submit' name='excluir' value='Excluir'  class='botao-excluir'>
                            </form>
            </td>
        </tr>";
}
?>

            </table>
        </div>
    </div>
       <!-- Ícone de guia -->
       <a id="guia-icon" href="ajuda.html">&#9432;</a>
    </div>
</body>
</html>
