<?php
// Incluindo arquivos necessários
include('auth.php');
include('config.php');

$mensagem = ""; // Variável para armazenar mensagens
$classe_mensagem = ""; // Variável para armazenar a classe da mensagem

// Verificando se o formulário de gravação foi enviado
// Verificando se o formulário de gravação foi enviado
if (isset($_POST['gravar'])) {
    $codigo = $_POST['codigo'];
    $nome = $_POST['nome'];

    // Formatação do CPF
    $cpf = preg_replace("/[^0-9]/", "", $_POST['cpf']);

    $relacao = $_POST['relacao'];

    // Formatação do Telefone
    $telefone = preg_replace("/[^0-9]/", "", $_POST['telefone']);

    // Preparando e executando a inserção no banco de dados
    $sql = "INSERT INTO pessoa (codigo, nome, cpf, relacao, telefone) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 'sssss', $codigo, $nome, $cpf, $relacao, $telefone);
    $resultado = mysqli_stmt_execute($stmt);

    // Exibindo mensagem com base no resultado da operação
    if ($resultado) {
        $mensagem = "Dados gravados com sucesso.";
        $classe_mensagem = "mensagem-sucesso";
    } else {
        $mensagem = "Erro ao gravar os dados: " . mysqli_error($con);
        $classe_mensagem = "mensagem-erro";
    }

    mysqli_stmt_close($stmt);
}


// Verificando se o formulário de alteração foi enviado
if (isset($_POST['alterar'])) {
    $codigo = $_POST['codigo'];
    $nome = $_POST['nome']; // Correção: atribuir a $_POST['nome'] a variável $nome
    $cpf = preg_replace("/[^0-9]/", "", $_POST['cpf']);
    $relacao = $_POST['relacao'];
    $telefone = preg_replace("/[^0-9]/", "", $_POST['telefone']);

    // Preparando e executando a atualização no banco de dados
    $sql = "UPDATE pessoa SET nome = ?, cpf = ?, relacao = ?, telefone = ? WHERE codigo = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 'sssss', $nome, $cpf, $relacao, $telefone, $codigo);
    $resultado = mysqli_stmt_execute($stmt);

    // Exibindo mensagem com base no resultado da operação
    if ($resultado) {
        $mensagem = "Dados alterados com sucesso.";
        $classe_mensagem = "mensagem-sucesso";
    } else {
        $mensagem = "Erro ao alterar os dados: " . mysqli_error($con);
        $classe_mensagem = "mensagem-erro";
    }

    mysqli_stmt_close($stmt);
}


// Verificando se o formulário de exclusão foi enviado
if (isset($_POST['excluir'])) {
    $codigo = $_POST['codigo'];

    // Preparando e executando a exclusão no banco de dados
    $sql = "DELETE FROM pessoa WHERE codigo = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 's', $codigo);
    $resultado = mysqli_stmt_execute($stmt);

    // Exibindo mensagem com base no resultado da operação
    if ($resultado) {
        $mensagem = "Dados excluídos com sucesso.";
        $classe_mensagem = "mensagem-sucesso";
    } else {
        $mensagem = "Erro ao excluir os dados: " . mysqli_error($con);
        $classe_mensagem = "mensagem-erro";
    }

    mysqli_stmt_close($stmt);
} elseif ($_POST['acao'] == 'pesquisar') {
    // Lógica para pesquisa
    $search_term = $_POST['search_term'];
    $query = "SELECT * FROM pessoa WHERE codigo LIKE '%$search_term%' OR cpf LIKE '%$search_term%'";
    $result = mysqli_query($con, $query);
} else {
    // Lógica padrão para obter e exibir todos os registros de pessoa na tabela
    $query = "SELECT * FROM pessoa";
    $result = mysqli_query($con, $query);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Style/style.css">
    <link rel="icon" href="img/oliares.png" type="image/x-icon">
    <title>Cadastro de Pessoas</title>
    <style>
        .mensagem {
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
            font-weight: bold;
            text-align: center;
        }

        .mensagem-sucesso {
            background-color: #4CAF50; /* Verde */
            color: white;
        }

        .mensagem-erro {
            background-color: #f44336; /* Vermelho */
            color: white;
        } 
        .botao-excluir {
            background-color: #f44336; /* Vermelho */
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        #guia-icon {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 50%;
            padding: 10px;
            font-size: 20px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        #guia-icon:hover {
            background-color: #0056b3;
        }

   

    </style>
</head>

<body>
    <div id="box">
        <div id='voltar'>
            <a href="home.php"><button type="submit" id="search-button" style="height: 40px;">Voltar</button></a>
        </div>
        <form name="formulario" method="post" action="pessoa.php">
            <h1>Cadastro de Pessoas</h1><br><br>
            Código:
            <input type="text" name="codigo" id="codigo" size=50 required>
            <br>
            Nome:
            <input type="text" name="nome" id="nome" size=50 required>
            <br>
            CPF:
            <input type="text" name="cpf" id="cpf" size=14 maxlength="14" required>
            <br>
            Relação:
            <select name="relacao" id="relacao" required>
                <option value="cliente" selected="selected">Cliente</option>
                <option value="Fornecedor">Fornecedor</option>
                <option value="Ambos">Ambos</option>
            </select>
            <br>
            Telefone:
            <input type="tel" name="telefone" id="telefone" size=14 maxlength="15" required>
            <br><br>

            <input type="submit" name="gravar" id="gravar" value="Gravar">
            <input type="submit" name="alterar" id="alterar" value="Alterar">
     
        </form>
        <?php
        if (!empty($mensagem)) {
            echo "<p class='mensagem $classe_mensagem'>$mensagem</p>";
        }
        ?>

        <div class="container">
            <div id="buttons-container">
                <br>
                <form id="search-form" method="post" action="">
                    <input type="text" id="search-input" name="search_term" style="height:30px;"
                        placeholder="Digite o código ou CPF para pesquisar">
                    <button type="submit" id="search-button" name="acao" value="pesquisar"
                        style="height: 40px;">Pesquisar</button>
                </form>
            </div>
            <table>
                <tr>
                    <th>Código</th>
                    <th>Nome</th>
                    <th>CPF</th>
                    <th>Relação</th>
                    <th>Telefone</th>
                    <th>Ação</th>
                </tr>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    // Formatando o CPF
                    $cpfFormatado = substr_replace(substr_replace(substr_replace($row['cpf'], '.', 3, 0), '.', 7, 0), '-', 11, 0);

                    // Formatando o telefone
                    $telefoneFormatado = '(' . substr($row['telefone'], 0, 2) . ') ' . substr($row['telefone'], 2, 5) . '-' . substr($row['telefone'], 7);

                    echo "<tr>
                        <td>{$row['codigo']}</td>
                        <td>{$row['nome']}</td>
                        <td>{$cpfFormatado}</td>
                        <td>{$row['relacao']}</td>
                        <td>{$telefoneFormatado}</td>
                        <td>
                            <form method='post' action='pessoa.php' onsubmit='return confirm(\"Deseja realmente excluir?\")'>
                                <input type='hidden' name='codigo' value='{$row['codigo']}'>
                                <input type='submit' name='excluir' value='Excluir'  class='botao-excluir'>
                            </form>
                            </td>
                    </tr>";
                }
                ?>
            </table>
        </div>
    </div>

    <script>
        // Adiciona evento oninput ao campo de CPF para formatar enquanto o usuário digita
        document.getElementById('cpf').addEventListener('input', function () {
            formatarCPF(this);
        });

        // Adiciona evento oninput ao campo de telefone para formatar enquanto o usuário digita
        document.getElementById('telefone').addEventListener('input', function () {
            formatarTelefone(this);
        });

        // Função para formatar o CPF
        function formatarCPF(element) {
            let value = element.value.replace(/\D/g, ''); // Remove caracteres não numéricos

            if (value.length <= 3) {
                // Quando o usuário está digitando os primeiros 3 dígitos
                element.value = value;
            } else if (value.length <= 6) {
                // Quando o usuário está digitando os próximos 3 dígitos
                element.value = value.substring(0, 3) + '.' + value.substring(3);
            } else if (value.length <= 9) {
                // Quando o usuário está digitando os próximos 3 dígitos
                element.value = value.substring(0, 3) + '.' + value.substring(3, 6) + '.' + value.substring(6);
            } else {
                // Quando o usuário já digitou todos os dígitos
                element.value = value.substring(0, 3) + '.' + value.substring(3, 6) + '.' + value.substring(6, 9) + '-' + value.substring(9);
            }
        }

        // Função para formatar o telefone
        function formatarTelefone(element) {
            let value = element.value.replace(/\D/g, ''); // Remove caracteres não numéricos

            if (value.length <= 2) {
                // Quando o usuário está digitando os primeiros 2 dígitos
                element.value = value;
            } else if (value.length <= 7) {
                // Quando o usuário está digitando os próximos 5 dígitos
                element.value = '(' + value.substring(0, 2) + ') ' + value.substring(2);
            } else {
                // Quando o usuário já digitou todos os dígitos
                element.value = '(' + value.substring(0, 2) + ') ' + value.substring(2, 7) + '-' + value.substring(7);
            }
        }
    </script>
       <!-- Ícone de guia -->
       <a id="guia-icon" href="ajuda.html">&#9432;</a>
    </div>
</body>

</html>






